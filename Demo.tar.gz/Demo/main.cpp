#include "behaviortree_cpp/bt_factory.h"
#include "ros/ros.h"
#include <iostream>
#include <chrono>
#include <thread>


class HelloWorld : public BT::ThreadedAction {
    public:
        HelloWorld(const std::string& name, const BT::NodeConfiguration& config)
            : BT::ThreadedAction(name, config)
        {
          i = 4;
        }
        static BT::PortsList providedPorts()
        {
            return{};
        }
        virtual BT::NodeStatus tick() override
        {
          std::cout << "Hello World start!" << std::endl;
          while (i--)
          {
            std::cout << "hello world.." << std::endl;
            std::this_thread::sleep_for(std::chrono::seconds(1));
          }
          std::cout << "Hello World finished!" << std::endl;
          return BT::NodeStatus::SUCCESS;
        }

    private:
        int i; 
};

class WaitForMoveState: public BT::SyncActionNode
{
    public:
        WaitForMoveState(const std::string& name, const BT::NodeConfiguration& config)
            : BT::SyncActionNode(name, config)
        {
          ros::param::set("/move", 100);
        }

        static BT::PortsList providedPorts()
        {
            return{};
        }

        virtual BT::NodeStatus tick() override
        {
          std::cout << "WaitForMoveState tick start" << std::endl;
          bool flag = false;
          while (!flag)
          {
            ros::param::get("/moveState", flag);
            std::cout << "Waiting for moveState: " << flag << std::endl;
            std::this_thread::sleep_for(std::chrono::seconds(1));
          }
          std::cout << "Move state received: " << flag << std::endl;
          std::cout << "WaitForMoveState tick finished" << std::endl;
          return BT::NodeStatus::SUCCESS;
        }
        
};

int main(int argc, char **argv)
{
  // Initialize node
  std::string nodeName = "behavior_tree";
  ros::init(argc, argv, nodeName);

  // Create node handle
  ros::NodeHandle node;

  // Create behavior tree factory
  BT::BehaviorTreeFactory factory;

  // Register nodes to factory
  factory.registerNodeType<HelloWorld>("HelloWorld");
  factory.registerNodeType<WaitForMoveState>("WaitForMoveState");

  // Create behavior tree from XML file
  BT::Tree tree = factory.createTreeFromFile("/home/sjy/jz/Tree/BehaviorTreeDemo/Demo/bt_tree.xml");

  // Run behavior tree
    auto status = BT::NodeStatus::RUNNING;
//  std::cout << "--- status: " << toStr(status) << "\n\n";
  while(status == BT::NodeStatus::RUNNING)
  {
      // Sleep to avoid busy loops.
      // do NOT use other sleep functions!
      // Small sleep time is OK, here we use a large one only to
      // have less messages on the console.
      status = tree.rootNode()->executeTick();
      std::this_thread::sleep_for(std::chrono::seconds(1));

      std::cout << "--- status: " << toStr(status) << "\n\n";
  }

  ros::spin();
  return 0;
}
